 /******************************************************************************
 *
 * File Name: main.c
 *
 * Description: Application layer
 *
 * Author: Abdelrahman ibrahim
 *
 *******************************************************************************/

#include "lcd.h"
#include "icu.h"
#include "ultrasonic.h"
#include <avr/io.h>


int main(void)
{
	uint16 distance;
	SREG|=(1<<7);
    LCD_init();
	Ultrasonic_init();
    LCD_displayString("distance= ");
    while(1)
    {
    	LCD_moveCursor(0,10);
    	distance=Ultrasonic_readDistance();
    	if(distance>=100)
    	{
    		LCD_intgerToString(distance);
    	}
    	else
    	{
    		LCD_intgerToString(distance);
    		LCD_displayCharacter(' ');
    	}
    	LCD_moveCursor(0,13);
    	LCD_displayString("cm");
    }
}
